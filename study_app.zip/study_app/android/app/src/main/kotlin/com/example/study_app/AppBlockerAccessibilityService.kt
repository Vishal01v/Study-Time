package com.example.study_app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Button

/**
 * Jab bhi koi app foreground mein aati hai, Android hume event bhejta hai.
 * Agar wo package blocked list mein hai AND blocking currently ON hai,
 * to hum GLOBAL_ACTION_HOME perform karke user ko wapas home screen par
 * bhej dete hain, aur ek chhota overlay message dikhate hain.
 *
 * IMPORTANT: Android kisi bhi app ko user se permission chheenne nahi
 * deta. User hamesha Settings > Accessibility > [ye service] > OFF kar
 * sakta hai — ye OS ka built-in safety rule hai aur isse bypass karna
 * Google Play policy todta hai, is liye hum aisa nahi karte. Strict Mode
 * sirf itna karta hai: (a) blocked app turant band karo, (b) agar user
 * khud ye service band karne ki koshish kare, to usey ek warning overlay
 * dikha dete hain (onInterrupt / onServiceConnected logic se) taaki wo
 * accidental na ho.
 */
class AppBlockerAccessibilityService : AccessibilityService() {

    private var overlayView: View? = null
    private var windowManager: WindowManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = AccessibilityServiceInfo.DEFAULT
        }
        serviceInfo = info
        AppBlockerStore.load(applicationContext)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        AppBlockerStore.load(applicationContext) // refresh latest state

        if (!AppBlockerStore.isBlocking) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return // apni hi app ko ignore karo

        if (AppBlockerStore.blockedPackages.contains(pkg)) {
            // User ko turant home bhej do
            performGlobalAction(GLOBAL_ACTION_HOME)
            showBlockOverlay()
        }
    }

    private fun showBlockOverlay() {
        // Agar overlay already dikh raha hai to dubara mat banao
        if (overlayView != null) return

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(40, 40, 40, 40)
        }
        val text = TextView(this).apply {
            text = "Ye app abhi study session ke liye blocked hai 🚫\nFocus rakho, thodi der mein break milega!"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
        }
        val dismiss = Button(this).apply {
            text = "Theek hai"
            setOnClickListener { removeOverlay() }
        }
        container.addView(text)
        container.addView(dismiss)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        // Note: TYPE_APPLICATION_OVERLAY ke liye "Draw over other apps"
        // permission bhi chahiye hogi (SYSTEM_ALERT_WINDOW) — app ko ye
        // pehli baar Settings se manually allow karwana padega.
        try {
            windowManager?.addView(container, params)
            overlayView = container
            container.postDelayed({ removeOverlay() }, 3000)
        } catch (e: Exception) {
            // Overlay permission na ho to silently skip karo — home action
            // to pehle hi ho chuka hai, app phir bhi band ho jaati hai.
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null
    }

    override fun onInterrupt() {
        // Service interrupt hone par kuch extra nahi karte —
        // Android khud hi user confirmation deta hai disable karte waqt.
    }
}
