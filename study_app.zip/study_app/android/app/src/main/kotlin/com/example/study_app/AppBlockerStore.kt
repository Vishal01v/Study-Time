package com.example.study_app

import android.content.Context

/**
 * Simple shared state between MainActivity (Flutter side) aur
 * AppBlockerAccessibilityService (background mein chalne wali service).
 * SharedPreferences use karte hain taaki process restart hone par bhi
 * state yaad rahe.
 */
object AppBlockerStore {
    private const val PREFS = "app_blocker_prefs"

    var blockedPackages: Set<String> = emptySet()
    var isBlocking: Boolean = false
    var strictMode: Boolean = false

    fun save(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putStringSet("blocked_packages", blockedPackages)
            .putBoolean("is_blocking", isBlocking)
            .putBoolean("strict_mode", strictMode)
            .apply()
    }

    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        blockedPackages = prefs.getStringSet("blocked_packages", emptySet()) ?: emptySet()
        isBlocking = prefs.getBoolean("is_blocking", false)
        strictMode = prefs.getBoolean("strict_mode", false)
    }
}
