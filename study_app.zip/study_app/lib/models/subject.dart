import 'package:flutter/material.dart';

/// Ek subject (Physics, Chemistry, Bio, Maths, etc.)
class Subject {
  final String id;
  String name;
  Color color;
  int dailyGoalMinutes; // har din ka target
  int todayMinutes; // aaj tak padha gaya time
  int totalMinutes; // overall total time

  Subject({
    required this.id,
    required this.name,
    required this.color,
    this.dailyGoalMinutes = 60,
    this.todayMinutes = 0,
    this.totalMinutes = 0,
  });

  double get progress =>
      dailyGoalMinutes == 0 ? 0 : (todayMinutes / dailyGoalMinutes).clamp(0, 1);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'color': color.value,
        'dailyGoalMinutes': dailyGoalMinutes,
        'todayMinutes': todayMinutes,
        'totalMinutes': totalMinutes,
      };

  factory Subject.fromJson(Map<String, dynamic> json) => Subject(
        id: json['id'],
        name: json['name'],
        color: Color(json['color']),
        dailyGoalMinutes: json['dailyGoalMinutes'] ?? 60,
        todayMinutes: json['todayMinutes'] ?? 0,
        totalMinutes: json['totalMinutes'] ?? 0,
      );
}

/// Default subjects jo app pehli baar open hone par milte hain
List<Subject> defaultSubjects() => [
      Subject(id: 'physics', name: 'Physics', color: Colors.blue, dailyGoalMinutes: 90),
      Subject(id: 'chemistry', name: 'Chemistry', color: Colors.green, dailyGoalMinutes: 90),
      Subject(id: 'bio', name: 'Biology', color: Colors.orange, dailyGoalMinutes: 60),
      Subject(id: 'maths', name: 'Maths', color: Colors.purple, dailyGoalMinutes: 90),
    ];
