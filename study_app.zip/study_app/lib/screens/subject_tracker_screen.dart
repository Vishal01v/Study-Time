import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/study_provider.dart';
import '../models/subject.dart';

class SubjectTrackerScreen extends StatelessWidget {
  const SubjectTrackerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final study = context.watch<StudyProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Subject Tracker')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addSubjectDialog(context, study),
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: study.subjects.length,
        itemBuilder: (context, i) {
          final s = study.subjects[i];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 6),
            child: ListTile(
              leading: CircleAvatar(backgroundColor: s.color, radius: 10),
              title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: s.progress,
                    color: s.color,
                    backgroundColor: s.color.withOpacity(0.15),
                  ),
                  const SizedBox(height: 4),
                  Text('Aaj: ${s.todayMinutes} min / Goal: ${s.dailyGoalMinutes} min'),
                  Text('Total ab tak: ${s.totalMinutes} min',
                      style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ],
              ),
              trailing: IconButton(
                icon: const Icon(Icons.edit, size: 20),
                onPressed: () => _editGoalDialog(context, study, s),
              ),
            ),
          );
        },
      ),
    );
  }

  void _editGoalDialog(BuildContext context, StudyProvider study, Subject s) {
    final controller = TextEditingController(text: s.dailyGoalMinutes.toString());
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${s.name} ka daily goal'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(suffixText: 'minutes/day'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final val = int.tryParse(controller.text) ?? s.dailyGoalMinutes;
              study.updateGoal(s.id, val);
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _addSubjectDialog(BuildContext context, StudyProvider study) {
    final nameController = TextEditingController();
    final goalController = TextEditingController(text: '60');
    Color picked = Colors.teal;
    final colorOptions = [
      Colors.teal, Colors.red, Colors.indigo, Colors.brown, Colors.pink, Colors.cyan,
    ];

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Naya Subject'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Subject naam'),
              ),
              TextField(
                controller: goalController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Daily goal (min)'),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: colorOptions
                    .map((c) => GestureDetector(
                          onTap: () => setState(() => picked = c),
                          child: CircleAvatar(
                            backgroundColor: c,
                            radius: picked == c ? 16 : 12,
                          ),
                        ))
                    .toList(),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.trim().isEmpty) return;
                study.addSubject(Subject(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  name: nameController.text.trim(),
                  color: picked,
                  dailyGoalMinutes: int.tryParse(goalController.text) ?? 60,
                ));
                Navigator.pop(context);
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }
}
