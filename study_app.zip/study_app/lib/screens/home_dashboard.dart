import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:provider/provider.dart';
import '../providers/study_provider.dart';
import 'pomodoro_screen.dart';
import 'subject_tracker_screen.dart';
import 'app_blocker_settings_screen.dart';

class HomeDashboard extends StatelessWidget {
  const HomeDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final study = context.watch<StudyProvider>();
    final goal = study.todayGoalMinutes == 0 ? 1 : study.todayGoalMinutes;
    final pct = (study.todayTotalMinutes / goal).clamp(0, 1).toDouble();

    return Scaffold(
      appBar: AppBar(title: const Text('Study Dashboard')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ---- Aaj ka overall progress ----
            Center(
              child: CircularPercentIndicator(
                radius: 90,
                lineWidth: 14,
                percent: pct,
                animation: true,
                circularStrokeCap: CircularStrokeCap.round,
                progressColor: Theme.of(context).colorScheme.primary,
                center: Text(
                  '${study.todayTotalMinutes}/${study.todayGoalMinutes}\nmin',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // ---- Quick actions ----
            Row(
              children: [
                Expanded(
                  child: _ActionCard(
                    icon: Icons.timer,
                    label: 'Pomodoro Timer',
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const PomodoroScreen())),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _ActionCard(
                    icon: Icons.menu_book,
                    label: 'Subject Tracker',
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const SubjectTrackerScreen())),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _ActionCard(
              icon: Icons.block,
              label: 'App Blocker / Strict Mode',
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const AppBlockerSettingsScreen())),
            ),
            const SizedBox(height: 24),

            // ---- Subject-wise mini progress list ----
            const Text('Aaj ka subject-wise progress',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            ...study.subjects.map((s) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      CircleAvatar(radius: 6, backgroundColor: s.color),
                      const SizedBox(width: 10),
                      SizedBox(width: 80, child: Text(s.name)),
                      Expanded(
                        child: LinearProgressIndicator(
                          value: s.progress,
                          color: s.color,
                          backgroundColor: s.color.withOpacity(0.15),
                          minHeight: 8,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text('${s.todayMinutes}/${s.dailyGoalMinutes}m'),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ActionCard({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
          child: Column(
            children: [
              Icon(icon, size: 30, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 8),
              Text(label, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
