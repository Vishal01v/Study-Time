import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/study_provider.dart';
import '../models/subject.dart';

class PomodoroScreen extends StatelessWidget {
  const PomodoroScreen({super.key});

  String _fmt(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String _phaseLabel(PomodoroPhase p) {
    switch (p) {
      case PomodoroPhase.work:
        return 'Study Session';
      case PomodoroPhase.shortBreak:
        return 'Short Break';
      case PomodoroPhase.longBreak:
        return 'Long Break';
      case PomodoroPhase.idle:
        return 'Ready?';
    }
  }

  @override
  Widget build(BuildContext context) {
    final study = context.watch<StudyProvider>();
    bool strictToggle = false;

    return Scaffold(
      appBar: AppBar(title: const Text('Pomodoro Timer')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // ---- Subject selector ----
              DropdownButton<Subject>(
                value: study.activeSubject,
                items: study.subjects
                    .map((s) => DropdownMenuItem(value: s, child: Text(s.name)))
                    .toList(),
                onChanged: study.isSessionRunning
                    ? null
                    : (s) {
                        if (s != null) study.setActiveSubject(s);
                      },
              ),
              const SizedBox(height: 24),

              Text(_phaseLabel(study.phase),
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              Text(
                study.phase == PomodoroPhase.idle
                    ? '${study.workMinutes}:00'
                    : _fmt(study.remainingSeconds),
                style: const TextStyle(fontSize: 56, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),

              if (study.phase == PomodoroPhase.idle) ...[
                StatefulBuilder(builder: (context, setState) {
                  return SwitchListTile(
                    title: const Text('Strict Mode'),
                    subtitle: const Text(
                        'Session ke dauran distracting apps block ho jaayengi'),
                    value: strictToggle,
                    onChanged: (v) => setState(() => strictToggle = v),
                  );
                }),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Start Session'),
                  style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14)),
                  onPressed: () => study.startWorkSession(strict: strictToggle),
                ),
              ] else
                OutlinedButton.icon(
                  icon: const Icon(Icons.stop),
                  label: const Text('Stop Session'),
                  onPressed: () => _confirmStop(context, study),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmStop(BuildContext context, StudyProvider study) {
    // Strict mode ON ho aur work phase chal raha ho to extra confirmation
    final isStrictWork =
        study.strictModeEnabled && study.phase == PomodoroPhase.work;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Session rokein?'),
        content: Text(isStrictWork
            ? 'Strict Mode ON hai. Abhi rokne par aapka progress is session ka save nahi hoga. Pakka rokna hai?'
            : 'Kya aap session rokna chahte hain?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Nahi')),
          TextButton(
            onPressed: () {
              study.stopSessionManually();
              Navigator.pop(context);
            },
            child: const Text('Haan, rokein'),
          ),
        ],
      ),
    );
  }
}
