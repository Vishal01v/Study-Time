import 'package:flutter/material.dart';
import '../services/app_blocker_channel.dart';

/// Yahan user:
/// 1. UsageStats permission deta hai (kaunsi app foreground mein hai, ye jaanne ke liye)
/// 2. AccessibilityService enable karta hai (block karne ke liye)
/// 3. Blocked apps ki list choose karta hai
class AppBlockerSettingsScreen extends StatefulWidget {
  const AppBlockerSettingsScreen({super.key});

  @override
  State<AppBlockerSettingsScreen> createState() => _AppBlockerSettingsScreenState();
}

class _AppBlockerSettingsScreenState extends State<AppBlockerSettingsScreen>
    with WidgetsBindingObserver {
  final _blocker = AppBlockerChannel();
  bool usageGranted = false;
  bool accessibilityGranted = false;

  // Demo list — real app mein PackageManager se installed apps nikaal kar
  // naam + icon ke sath dikhate (device_apps jaisa package use ho sakta hai).
  final Map<String, String> commonApps = {
    'com.instagram.android': 'Instagram',
    'com.google.android.youtube': 'YouTube',
    'com.whatsapp': 'WhatsApp',
    'com.zhiliaoapp.musically': 'TikTok',
    'com.snapchat.android': 'Snapchat',
    'com.facebook.katana': 'Facebook',
  };
  final Set<String> selected = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshPermissions();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // User Settings se wapas aaye to permission status dobara check karo
    if (state == AppLifecycleState.resumed) _refreshPermissions();
  }

  Future<void> _refreshPermissions() async {
    final u = await _blocker.hasUsageStatsPermission();
    final a = await _blocker.isAccessibilityServiceEnabled();
    setState(() {
      usageGranted = u;
      accessibilityGranted = a;
    });
  }

  @override
  Widget build(BuildContext context) {
    final ready = usageGranted && accessibilityGranted;

    return Scaffold(
      appBar: AppBar(title: const Text('App Blocker Setup')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Step 1: Permissions', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _PermissionTile(
            title: 'Usage Access',
            subtitle: 'Foreground app detect karne ke liye zaroori',
            granted: usageGranted,
            onTap: _blocker.requestUsageStatsPermission,
          ),
          _PermissionTile(
            title: 'Accessibility Service',
            subtitle: 'Blocked app khulte hi wapas home screen bhejne ke liye',
            granted: accessibilityGranted,
            onTap: _blocker.openAccessibilitySettings,
          ),
          const Divider(height: 32),

          const Text('Step 2: Block karne wali apps chunein',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...commonApps.entries.map((e) => CheckboxListTile(
                title: Text(e.value),
                value: selected.contains(e.key),
                onChanged: (v) {
                  setState(() {
                    if (v == true) {
                      selected.add(e.key);
                    } else {
                      selected.remove(e.key);
                    }
                  });
                },
              )),
          const SizedBox(height: 16),

          if (!ready)
            const Text(
              'Pehle dono permissions ON karein taaki blocker kaam kar sake.',
              style: TextStyle(color: Colors.red),
            ),

          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: ready && selected.isNotEmpty
                ? () async {
                    await _blocker.setBlockedApps(selected.toList());
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Blocked list saved.')),
                      );
                    }
                  }
                : null,
            child: const Text('Save Blocked Apps'),
          ),

          const SizedBox(height: 24),
          Card(
            color: Colors.amber.shade50,
            child: const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'Note: Android, security ke liye user ko hamesha Settings se '
                'Accessibility Service manually band karne deta hai — ise poori '
                'tarah block karna OS policy ke khilaf hai. Strict Mode isliye '
                'session ke beech "band karna mushkil + warning" wala design hai, '
                '"bilkul band na ho sake" wala nahi.',
                style: TextStyle(fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PermissionTile extends StatelessWidget {
  final String title, subtitle;
  final bool granted;
  final VoidCallback onTap;
  const _PermissionTile(
      {required this.title, required this.subtitle, required this.granted, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: granted
            ? const Icon(Icons.check_circle, color: Colors.green)
            : TextButton(onPressed: onTap, child: const Text('Enable')),
      ),
    );
  }
}
