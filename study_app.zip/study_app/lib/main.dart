import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/study_provider.dart';
import 'screens/home_dashboard.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => StudyProvider(),
      child: const StudyApp(),
    ),
  );
}

class StudyApp extends StatelessWidget {
  const StudyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Study Companion',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const HomeDashboard(),
    );
  }
}
