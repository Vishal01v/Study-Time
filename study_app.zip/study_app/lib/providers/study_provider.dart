import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/subject.dart';
import '../services/app_blocker_channel.dart';

enum PomodoroPhase { idle, work, shortBreak, longBreak }

/// App ka central brain — subjects, pomodoro timer aur blocker state
/// sab yahin manage hota hai (ChangeNotifier via provider package).
class StudyProvider extends ChangeNotifier {
  StudyProvider() {
    _load();
  }

  // ---------- Subjects ----------
  List<Subject> subjects = [];
  Subject? activeSubject;

  // ---------- Pomodoro ----------
  PomodoroPhase phase = PomodoroPhase.idle;
  int workMinutes = 25;
  int shortBreakMinutes = 5;
  int longBreakMinutes = 15;
  int cyclesBeforeLongBreak = 4;
  int completedCycles = 0;

  int remainingSeconds = 0;
  Timer? _ticker;

  // ---------- Strict / Blocker ----------
  bool strictModeEnabled = false;
  bool get isSessionRunning => phase == PomodoroPhase.work && _ticker != null;

  final AppBlockerChannel _blocker = AppBlockerChannel();

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('subjects');
    if (raw != null) {
      final list = jsonDecode(raw) as List;
      subjects = list.map((e) => Subject.fromJson(e)).toList();
    } else {
      subjects = defaultSubjects();
    }
    activeSubject = subjects.isNotEmpty ? subjects.first : null;
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('subjects', jsonEncode(subjects.map((s) => s.toJson()).toList()));
  }

  // ---------- Subject CRUD ----------
  void addSubject(Subject s) {
    subjects.add(s);
    _save();
    notifyListeners();
  }

  void updateGoal(String id, int minutes) {
    final s = subjects.firstWhere((e) => e.id == id);
    s.dailyGoalMinutes = minutes;
    _save();
    notifyListeners();
  }

  void setActiveSubject(Subject s) {
    activeSubject = s;
    notifyListeners();
  }

  int get todayTotalMinutes => subjects.fold(0, (sum, s) => sum + s.todayMinutes);
  int get todayGoalMinutes => subjects.fold(0, (sum, s) => sum + s.dailyGoalMinutes);

  // ---------- Pomodoro control ----------
  void startWorkSession({bool strict = false}) {
    strictModeEnabled = strict;
    phase = PomodoroPhase.work;
    remainingSeconds = workMinutes * 60;
    _startTicker();

    if (strict) {
      // Native Android App Blocker ko on karo — session khatam hone tak
      // chuni hui apps (Instagram, YouTube, games...) block rahengi.
      _blocker.startBlocking(strict: true);
    }
    notifyListeners();
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (t) {
      if (remainingSeconds > 0) {
        remainingSeconds--;
        notifyListeners();
      } else {
        _onPhaseComplete();
      }
    });
  }

  void _onPhaseComplete() {
    if (phase == PomodoroPhase.work) {
      // Study time ko active subject mein add karo
      if (activeSubject != null) {
        activeSubject!.todayMinutes += workMinutes;
        activeSubject!.totalMinutes += workMinutes;
        _save();
      }
      completedCycles++;

      // Work session khatam -> blocker hata do (break ke dauran apps allowed)
      _blocker.stopBlocking();

      final isLong = completedCycles % cyclesBeforeLongBreak == 0;
      phase = isLong ? PomodoroPhase.longBreak : PomodoroPhase.shortBreak;
      remainingSeconds = (isLong ? longBreakMinutes : shortBreakMinutes) * 60;
      _startTicker();
    } else {
      // break khatam -> idle, agla session start karne ka wait
      phase = PomodoroPhase.idle;
      _ticker?.cancel();
      _ticker = null;
    }
    notifyListeners();
  }

  /// User session beech mein rokna chahta hai.
  /// Strict mode ON ho to ye sirf confirm karke hi allow hota hai —
  /// UI layer (pomodoro_screen.dart) is par warning dialog dikhata hai.
  void stopSessionManually() {
    _ticker?.cancel();
    _ticker = null;
    phase = PomodoroPhase.idle;
    _blocker.stopBlocking();
    notifyListeners();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
