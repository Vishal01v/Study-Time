import 'package:flutter/services.dart';

/// Flutter <-> Android native bridge.
/// Native side: MainActivity.kt + AppBlockerAccessibilityService.kt
class AppBlockerChannel {
  static const _channel = MethodChannel('study_app/blocker');

  /// UsageStats permission diya hua hai ya nahi, check karo
  Future<bool> hasUsageStatsPermission() async {
    final result = await _channel.invokeMethod<bool>('hasUsageStatsPermission');
    return result ?? false;
  }

  /// User ko Settings > Usage Access screen par le jao
  Future<void> requestUsageStatsPermission() async {
    await _channel.invokeMethod('requestUsageStatsPermission');
  }

  /// AccessibilityService on hai ya nahi
  Future<bool> isAccessibilityServiceEnabled() async {
    final result = await _channel.invokeMethod<bool>('isAccessibilityServiceEnabled');
    return result ?? false;
  }

  /// User ko Settings > Accessibility screen par le jao taaki
  /// wo humari service ko manually enable kar sake
  Future<void> openAccessibilitySettings() async {
    await _channel.invokeMethod('openAccessibilitySettings');
  }

  /// Blocked packages ki list set karo, e.g. ["com.instagram.android", "com.google.android.youtube"]
  Future<void> setBlockedApps(List<String> packageNames) async {
    await _channel.invokeMethod('setBlockedApps', {'packages': packageNames});
  }

  /// Blocking start karo. strict=true matlab is session ke andar
  /// user AccessibilityService disable karne ki koshish kare to
  /// warning overlay dikhega (OS level permission ko force bypass
  /// karna possible nahi hai aur na hi suggested hai).
  Future<void> startBlocking({required bool strict}) async {
    await _channel.invokeMethod('startBlocking', {'strict': strict});
  }

  Future<void> stopBlocking() async {
    await _channel.invokeMethod('stopBlocking');
  }
}
