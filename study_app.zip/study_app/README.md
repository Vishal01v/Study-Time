# Study Companion — Flutter App

## Setup
```
flutter create --platforms=android study_app_tmp   # sirf android/ gradle wrapper lene ke liye agar missing ho
flutter pub get
flutter run
```
Project ka `android/app/src/main/AndroidManifest.xml`, `kotlin/` aur `res/xml` is zip mein already bana hua hai — apne naye `flutter create` project ke upar inhe copy/merge kar dein (package name `com.example.study_app` match hona chahiye, ya apna khud ka rename kar lein).

## Flow
1. **Home Dashboard** (`lib/screens/home_dashboard.dart`) — aaj ka overall progress + quick links.
2. **Pomodoro Timer** (`lib/screens/pomodoro_screen.dart`) — 25/5/15 min cycles, subject-wise.
3. **Subject Tracker** (`lib/screens/subject_tracker_screen.dart`) — Physics/Chem/Bio/Maths, har ek ka apna daily goal.
4. **App Blocker** (`lib/screens/app_blocker_settings_screen.dart` + native Kotlin) — UsageStats + AccessibilityService se blocked apps ko turant home par bhej deta hai jab Strict Mode ON ho.

## Zaroori limitation (important!)
Android **kisi bhi app ko poori tarah "unkillable" nahi banana deta** — user hamesha:
- Settings > Accessibility se service manually OFF kar sakta hai
- App ko Force Stop / Uninstall kar sakta hai
- Phone restart kar sakta hai

Ye Android ka security-by-design rule hai; isko bypass karne ki koshish karna Google Play Developer Policy todta hai aur malware jaisa behavior ban jaata hai. Is liye "Strict Mode" ka matlab yahan **"band karna jaan-bujh kar mushkil/friction-full"** hai (turant blocked app band karna + warning overlay), na ki **"OS-level se disable hi na ho sake"**. Agar aapko aur zyada friction chahiye, aap:
- Confirmation dialog + 10 second delay Settings khulne se pehle
- Parent/accountability-partner ko notification (Firebase) jab user accessibility service off kare
ye features add kar sakte hain — inke liye bata dein, main wo bhi jod dunga.
